
import java.util.*;
public class Strings2Q6 {
	 public static List<Integer> findAnagrams(String s, String p) {
	        List<Integer> result = new ArrayList<>();
	        if (s.length() < p.length()) {
	            return result;
	        }

	        int[] targetCount = new int[26];
	        int[] windowCount = new int[26];

	        // Count the characters in the pattern string p
	        for (char c : p.toCharArray()) {
	            targetCount[c - 'a']++;
	        }

	        int left = 0;
	        int right = 0;
	        int count = 0;

	        while (right < s.length()) {
	            char currentChar = s.charAt(right);
	            windowCount[currentChar - 'a']++;
	            if (targetCount[currentChar - 'a'] > 0 && windowCount[currentChar - 'a'] <= targetCount[currentChar - 'a']) {
	                count++;
	            }

	            // Slide the window
	            while (count == p.length()) {
	                if (right - left + 1 == p.length()) {
	                    result.add(left);
	                }

	                char leftChar = s.charAt(left);
	                windowCount[leftChar - 'a']--;
	                if (targetCount[leftChar - 'a'] > 0 && windowCount[leftChar - 'a'] < targetCount[leftChar - 'a']) {
	                    count--;
	                }

	                left++;
	            }

	            right++;
	        }

	        return result;
	    }
	public static void main(String[] args) {
		String s = "cbaebabacd";
		String p = "abc";

		List<Integer> result = findAnagrams(s, p);
		System.out.println(result); // Output: [0, 6]


	}

}



