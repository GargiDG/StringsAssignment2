
public class Strings2Q2 {
	public static boolean checkValidString(String s) {
        int minOpen = 0;  // Minimum number of open parentheses
        int maxOpen = 0;  // Maximum number of open parentheses
        
        for (char c : s.toCharArray()) {
            if (c == '(') {
                minOpen++;
                maxOpen++;
            } else if (c == ')') {
                minOpen = Math.max(minOpen - 1, 0);  // Treat '*' as empty string
                maxOpen--;
                if (maxOpen < 0) {
                    return false;  // More closing parentheses than opening parentheses
                }
            } else if (c == '*') {
                minOpen = Math.max(minOpen - 1, 0);  // Treat '*' as empty string
                maxOpen++;  // Treat '*' as open parenthesis
            }
        }
        
        return minOpen == 0;  // All open parentheses are matched
    }
	public static void main(String[] args) {
		String s = "()";
		boolean isValid = checkValidString(s);
		System.out.println(isValid); // Output: true


	}

}



