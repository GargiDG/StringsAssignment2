import java.util.*;
class TreeNode {
    int val;
    TreeNode left;
    TreeNode right;

    TreeNode(int val) {
        this.val = val;
    }
}
 class MainSolution {
	 public TreeNode str2tree(String s) {
	        if (s.isEmpty()) {
	            return null;
	        }

	        int firstParenthesis = s.indexOf("(");

	        int rootValue;
	        if (firstParenthesis == -1) {
	            rootValue = Integer.parseInt(s);
	            return new TreeNode(rootValue);
	        }

	        rootValue = Integer.parseInt(s.substring(0, firstParenthesis));
	        TreeNode root = new TreeNode(rootValue);

	        int start = firstParenthesis;
	        int count = 0;
	        for (int i = start; i < s.length(); i++) {
	            if (s.charAt(i) == '(') {
	                count++;
	            } else if (s.charAt(i) == ')') {
	                count--;
	            }

	            if (count == 0 && start == firstParenthesis) {
	                root.left = str2tree(s.substring(start + 1, i));
	                start = i + 1;
	            } else if (count == 0) {
	                root.right = str2tree(s.substring(start + 1, i));
	            }
	        }

	        return root;
	        
	 }
 
	 // Helper method to perform preorder traversal of the binary tree
	 public List<Integer> preorderTraversal(TreeNode root) {
	        List<Integer> result = new ArrayList<>();
	        if (root != null) {
	            result.add(root.val);
	            result.addAll(preorderTraversal(root.left));
	            result.addAll(preorderTraversal(root.right));
	        }
	        return result;
	    }
 }

    public class Strings2Q4{
	public static void main(String[] args) {
		String s = "4(2(3)(1))(6(5))";
		MainSolution solution = new MainSolution();
		TreeNode root = solution.str2tree(s);
		List<Integer> result = solution.preorderTraversal(root);
		System.out.println(result); // Output: [4, 2, 3, 1, 6, 5]

	}

}






   
   