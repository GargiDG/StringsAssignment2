
public class Strings2Q5 {
	public static int compress(char[] chars) {
        int n = chars.length;
        int resultIndex = 0; // Index to update the compressed characters
        
        for (int i = 0; i < n; ) {
            char currentChar = chars[i];
            int count = 0;
            
            // Count the number of consecutive occurrences of currentChar
            while (i < n && chars[i] == currentChar) {
                count++;
                i++;
            }
            
            // Update the character at resultIndex
            chars[resultIndex++] = currentChar;
            
            // If count > 1, update the character with its count
            if (count > 1) {
                String countStr = String.valueOf(count);
                
                // Split the count into individual characters if count >= 10
                for (char c : countStr.toCharArray()) {
                    chars[resultIndex++] = c;
                }
            }
        }
        
        return resultIndex;
    }
	public static void main(String[] args) {
		char[] chars = {'a','a','b','b','c','c','c'};
		int newLength =compress(chars);

		// Print the compressed characters and their count
		for (int i = 0; i < newLength; i++) {
		    System.out.print(chars[i] + " ");
		}
		System.out.println();


	}

}


